package brickBreaker;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField; 


public class Main {
	

	public static void main(String[] args) {	

		JFrame f = new JFrame();
		f.setBounds(10, 10, 600, 600);
		f.setTitle("BRICK BREAKER");
     	
		
		JButton b1  = new JButton("Start Game");
		JTextField t1= new JTextField();
		JLabel l1 = new JLabel("Player :");
		
	   
     	b1.setBounds(160,200,200,50);
		t1.setBounds(300,120,150,50);
		l1.setBounds(50,100,500,80);
		l1.setFont(new Font("", Font.BOLD,60));
		t1.setFont(new Font("",Font.PLAIN,30));
		
		
		f.add(b1);
		f.add(l1);
		f.add(t1);
		
		f.setLayout(null);
		f.setResizable(false);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		
		b1.addActionListener(new ActionListener()
		{
		 public void actionPerformed(ActionEvent e)
		{      
			  gameplay gp = new gameplay();
		      JFrame f1=new JFrame();// frame of first level
		      f1.setBounds(10,10,1520,800);
			  f1.setTitle("BrickBreaker");
			  f1.setResizable(false);
			  f1.add(gp);
			  f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		      f1.setVisible(true);
		      
			   

		}
			
		});
		
		
		
		
		
		
		
	}



	


	//@Override
	//public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	//}
	
}