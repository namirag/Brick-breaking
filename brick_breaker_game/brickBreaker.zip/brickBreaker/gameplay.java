package brickBreaker;
//package brickBracker;
import java.awt.Color;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JPanel;

//keylistener for the keyboard key and actionlisnter for ball in game to detect.
public class gameplay extends JPanel implements KeyListener, ActionListener{
	private static final Graphics Graphics = null;
	private boolean play = false;// making it false because we don't want our game play automatically.
	private int score = 0;// making score zero whenever player start to play.
	int ballface=3;// 3  lifelines 
	private int totalbricks = 12;//making it by 7*3 by matrix block.
	private Timer time;//timer for game
	private int delay =1 ;
	 
	private int playerx = 310;//setting position of slider.
	
	private int ballposx = 400;//x-axis----ball position
	private int ballposy = 730;//y-axis----ball position
	private int ballxdir = -2;
	private int ballydir = -5;
	public int levelflag = 0;
	private mapgenerator map;//calling map class
	Graphics g;
	public gameplay() {
		map = new mapgenerator(3,4);
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		time = new Timer(delay, this);
		time.start();
		
	}
	public void paint(Graphics g)
	{
		//background
		g.setColor(Color.GRAY);
		g.fillRect(1,1,3992,3992);
		
		//draw function form mapgenerator
		map.draw((Graphics2D)g);
		
		//borders
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0,0,5,1520);//y-axis right side
		g.fillRect(0,0,1500,5);//x-axis top side
		g.fillRect(1500,0,5,900);//y-axis left side
		g.fillRect(0,758,1520,5);//x-axis bottom side
	
		//scores
		g.setColor(Color.black);
		g.setFont(new Font("Dialog", Font.PLAIN,30));
		g.drawString(" points : "+score, 500, 30);
		//paddle
		g.setColor(Color.green);
		g.fill3DRect(playerx, 750, 100, 8,false);
		
		if(ballface>=1)
		{
			g.setColor(Color.black);
			g.setFont(new Font("Dialog", Font.BOLD,30));
			g.drawString("Life : "+ballface,1200,30);
		}
		
		//ball
		g.setColor(Color.yellow);
		g.fillOval(ballposx,ballposy,20,20);//using oval to show ball in a particular shape. 
		if(totalbricks == 0 ) {
			play = false;
			levelflag=1;
			ballxdir = 0;
			ballydir = 0;
			g.dispose();
			JFrame f2=new JFrame();
		    gameplay l1=new gameplay();
		       f2.setBounds(10,10,1520,800);
		       f2.setTitle("BrickBreaker");
		       f2.setResizable(false);
				 f2.add(l1);
				 f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			     f2.setVisible(true);
			
		
		}
		
		if(levelflag == 1)
		{
			levelflag = 0;
			totalbricks =15;
			JFrame f2=new JFrame();
		       gameplay1 gp1 =new gameplay1();
		       f2.setBounds(10,10,1520,800);
		       f2.setTitle("BrickBreaker");
		       f2.setResizable(false);
		       f2.add(gp1);
			   f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			   f2.setVisible(true);
		}
			
		if(ballposy > 800)//level of ball 
			{   play=false;
				ballface--;
				if(ballface<1)
				{	
			        
					ballxdir = 0;
					ballydir = 0;
				    g.setColor(Color.black);
					g.setFont(new Font("SansSerif", Font.BOLD,30));
					g.drawString(" GAME OVER , YOU SCORE : "+score, 500, 400);
				}
				else
				{
					
					
					ballposx =400;
					ballposy =730;
					ballxdir = -2;
					ballydir = -5;
					playerx = 310;
					repaint ();
					
				}
				
			}
			g.dispose();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		time.start();
		//creating actions for ball by boolean values (true or false) if the key right or left is pressed, it will be true if any R or L is pressed.  
		if (play) 
		{
			if(new Rectangle(ballposx,ballposy,20,20).intersects(new Rectangle(playerx, 750,100,8)))//to intersect ball with paddel
			{
				ballydir = -ballydir;
			}
			a:for(int i=0; i<map.map.length; i++)//first map is the variable/object of constructor calling mapgenerator class, and second map is variable form mapg class
			{
				for(int j=0; j<map.map[0].length; j++)
				{
					if (map.map[i][j] > 0)
					{
						int brickx = j * map.brickwidth +80;
						int bricky = i * map.brickheight +50;
						int bw = map.brickwidth;
						int bh = map.brickheight;
						
						Rectangle rect = new Rectangle(brickx, bricky, bw, bh);
						Rectangle ballrect = new Rectangle(ballposx, ballposy, 20,20);
						Rectangle brickrect = rect;
						
						if (ballrect.intersects(brickrect)) {
							map.setbrickvalue(0, i, j);
							totalbricks--;
							score+=5;

							if (ballposx + 19 <= brickrect.x || ballposx +1 >= brickrect.x +brickrect.width) 
							{
								ballxdir = -ballxdir;
							}
							else
							{
								ballydir = -ballydir;
							}
							break a;
						}
					}
				}
			}
			ballposx += ballxdir;
			ballposy += ballydir;
			
			if(ballposx < 0) //for the left border
			{
				ballxdir = -ballxdir;
			}
			if(ballposy < 0) //top
			{
				ballydir = -ballydir;
			}
			if(ballposx > 1450) //for right border
			{
				ballxdir = -ballxdir;
			}
		}
		repaint();//it will call paint method again repetadly because when the game gets over or player losses we need to start game again as it was.
		//in other word to call paddle again when game gets over we need to call.
	}
	

@Override
	public void keyTyped(KeyEvent e) {}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
			System.out.println("Right");
			if (playerx >= 1400) //limit of paddel right side
			{
				System.out.println("value "+playerx);
				playerx = 1400;
			}
			else
			{
				System.out.println("Else Part of Right "+playerx);
				
				moveRIGHT();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_LEFT) {
			System.out.println("left");
			if(playerx < 10)
			{
				System.out.println("value "+playerx);
				playerx = 10;
			}
			else
			{
				System.out.println("Else Part of Left "+playerx);
				moveLEFT();
			}
		}
		
		if(e.getKeyCode() == KeyEvent.VK_K) {
			if(!play)
				play=true;
			else 
			play=false;
		}
		
	} 
	public void moveRIGHT()
	{
		play = true;
		playerx +=20;
	}
	public void moveLEFT()
	{
		play = true;
		playerx -=20;
	}

	@Override
	public void keyReleased(KeyEvent e) {
	}

}
