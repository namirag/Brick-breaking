package brickBreaker;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;


//level 2
public class mapgenerator1 {
		public int map[][];
		public int brickheight;
		public int brickwidth;
		
		public mapgenerator1(int row, int col) {
			map = new int[row][col];
			for(int i= 0;i<map.length;i++)
			{
				for(int j=i;j<(map[0].length)-i;j++)
				{ 
					
					map[i][j] = 1;//logic of initializing to one is this particular brick is not been interacted with ball, so it may shown on pannel.
				  
				}   
			
			}
			brickwidth = 1350/col;
			brickheight = 350/row;
		}
		public void draw(Graphics2D g) {
			for(int i=0; i < map.length; i++) {
				for(int j=0; j< (map[0].length); j++) {
					if (map[i][j] >0)
					{
						g.setColor(Color.WHITE);
						
						g.fillRect( j * brickwidth + 80, i * brickheight + 50, brickwidth, brickheight);
						
						g.setStroke(new BasicStroke(3));
						g.setColor(Color.GRAY);
						
						g.drawRect(j * brickwidth + 80, i * brickheight + 50, brickwidth, brickheight);
						
					}
				}
			}
		}
		public void setbrickvalue(int val, int row, int col) {
			map[row][col] = val;
		}
	}