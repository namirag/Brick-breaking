package brickBreaker;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JPanel;

//keylistener for the keyboard key and actionlisnter for ball in game to detect.
public class gameplay1 extends JPanel  implements KeyListener, ActionListener{
private boolean play = false;// making it false because we don't want our game play automatically.
	private int score = 0;// making score zero whenever player start to play.
	int ballface=3;
	private int totalbricks = 15;//making it by 7*3 by matrix block.
	private Timer time;//timer for game
	private int delay =1 ;
	
	 
	private int playerx = 310;//setting position of slider.
	private int ballposx = 400;//x-axis----ball position
	private int ballposy = 730;//y-axis----ball position
	private int ballxdir = -3;
	private int ballydir = -5;
	
	
	
	private mapgenerator1  map1;//calling map class
	
	public gameplay1() {
		map1 = new mapgenerator1(3,7);
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		time = new Timer(delay, this);
		time.start();
			
	}
	public void paint(Graphics g)
	{
		//background
		g.setColor(Color.GRAY);
		g.fillRect(1,1,3992,3992);
		
		//draw function form mapgenerator
		map1.draw((Graphics2D)g);
		
		//borders
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0,0,5,1520);//y-axis right side
		g.fillRect(0,0,1500,5);//x-axis top side
		g.fillRect(1500,0,5,900);//y-axis left side
		g.fillRect(0,758,1520,5);//x-axis bottom side
		
		//scores
		g.setColor(Color.black);
		g.setFont(new Font("Dialog", Font.PLAIN,30));
		g.drawString(" points : "+score, 500, 30);
		//paddle
		g.setColor(Color.green);
		g.fill3DRect(playerx, 750, 100, 8,false);

		
		if(ballface>=1)
		{
			g.setColor(Color.black);
			g.setFont(new Font("Dialog", Font.BOLD,30));
			
			g.drawString("Life : "+ballface,1200,30);
			
		}
		
		//ball
		g.setColor(Color.yellow);
		g.fillOval(ballposx,ballposy,20,20);//using oval to show ball in a particular shape. 
		if(totalbricks==0 ) {
			
			
			play = false;
			ballxdir = 0;
			ballydir = 0;
		
			
			
			      
			g.setColor(Color.YELLOW);
			g.setFont(new Font("", Font.BOLD,30));
			g.drawString(" YOU WON ", 190, 300);
			g.setFont(new Font("SansSerif", Font.BOLD,20));
			g.drawString(" Press ENTER to Restart. ", 230, 350);
		}
		

		
			if(ballposy > 800)//level of ball 
			{   play=false;
				ballface--;
				if(ballface<1)
				{	
					ballxdir = 0;
					ballydir = 0;
				    g.setColor(Color.black);
					g.setFont(new Font("SansSerif", Font.BOLD,30));
					g.drawString(" GAME OVER , YOU SCORE : "+score, 500, 400);
				}
				else
				{
					
					
					ballposx =400;
					ballposy =730;
					ballxdir = -3;
					ballydir = -5;
					playerx = 310;
					repaint ();
					
				}
				
			}
			g.dispose();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		time.start();
		//creating actions for ball by boolean values (true or false) if the key right or left is pressed, it will be true if any R or L is pressed.  
		if (play) 
		{
			if(new Rectangle(ballposx,ballposy,20,20).intersects(new Rectangle(playerx, 750,100,8)))//to intersect ball with paddel
			{
				ballydir = -ballydir;
			}
			a:for(int i=0; i<map1.map.length; i++)//first map is the variable/object of constructor calling mapgenerator class, and second map is variable form mapg class
			{
				for(int j=0; j<map1.map[0].length; j++)
				{
					if (map1.map[i][j] > 0)
					{
						int brickx = j * map1.brickwidth +80;
						int bricky = i * map1.brickheight +50;
						int bw = map1.brickwidth;
						int bh = map1.brickheight;
						
						Rectangle rect = new Rectangle(brickx, bricky, bw, bh);
						Rectangle ballrect = new Rectangle(ballposx, ballposy, 20,20);
						Rectangle brickrect = rect;
						
						if (ballrect.intersects(brickrect)) {
							map1.setbrickvalue(0, i, j);
							totalbricks--;
							score +=5;
						
							

							if (ballposx + 19 <= brickrect.x || ballposx +1 >= brickrect.x +brickrect.width) 
							{
								ballxdir = -ballxdir;
							}
							else
							{
								ballydir = -ballydir;
							}
							break a;
						}
					}
				}
			}
			ballposx += ballxdir;
			ballposy += ballydir;
			
			if(ballposx < 0) //for the left border
			{
				ballxdir = -ballxdir;
			}
			if(ballposy < 0) //top
			{
				ballydir = -ballydir;
			}
			if(ballposx > 1450) //for right border
			{
				ballxdir = -ballxdir;
			}
		}
		repaint();//it will call paint method again repetadly because when the game gets over or player losses we need to start game again as it was.
		//in other word to call paddle again when game gets over we need to call.
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}
	

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
			
			if (playerx >= 1400) //limit of paddel right side
			{
				
				playerx = 1400;
			}
			else
			{
				
				
				moveRIGHT();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_LEFT) {
			System.out.println("left");
			if(playerx < 10)
			{
				
				playerx = 10;
			}
			else
			{
			
				moveLEFT();
			} 
		}
		
		if(e.getKeyCode() == KeyEvent.VK_K)
		{
		  if(!play)
			  play=true;
		  else 
			  play=false;
		}
			
	}
	public void moveRIGHT()
	{
		play = true;
		playerx +=20;
	}
	public void moveLEFT()
	{
		play = true;
		playerx -=20;
	}

	@Override
	public void keyReleased(KeyEvent e) {
	}

}


